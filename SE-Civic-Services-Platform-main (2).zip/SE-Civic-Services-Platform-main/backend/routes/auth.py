from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token
from database.db import db
from models.user import User

auth_bp = Blueprint("auth", __name__)


# -------------------------
# User Registration
# -------------------------
@auth_bp.route("/signup", methods=["POST"])
def signup():

    data = request.get_json()

    full_name = data.get("full_name")
    email = data.get("email")
    phone = data.get("phone")
    password = data.get("password")
    role = data.get("role", "Citizen")

    # Validate required fields
    if not all([full_name, email, phone, password]):
        return jsonify({
            "success": False,
            "message": "All fields are required."
        }), 400

    # Check if email already exists
    if User.query.filter_by(email=email).first():
        return jsonify({
            "success": False,
            "message": "Email already registered."
        }), 400

    # Check if phone already exists
    if User.query.filter_by(phone=phone).first():
        return jsonify({
            "success": False,
            "message": "Phone number already registered."
        }), 400

    # Create user
    user = User(
        full_name=full_name,
        email=email,
        phone=phone,
        role=role
    )

    user.set_password(password)

    db.session.add(user)
    db.session.commit()

    return jsonify({
        "success": True,
        "message": "Registration successful."
    }), 201


# -------------------------
# User Login
# -------------------------
@auth_bp.route("/login", methods=["POST"])
def login():

    data = request.get_json()

    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return jsonify({
            "success": False,
            "message": "Email and password are required."
        }), 400

    user = User.query.filter_by(email=email).first()

    if user is None:
        return jsonify({
            "success": False,
            "message": "User not found."
        }), 404

    if not user.check_password(password):
        return jsonify({
            "success": False,
            "message": "Incorrect password."
        }), 401

    access_token = create_access_token(identity=user.id)

    return jsonify({
        "success": True,
        "message": "Login successful.",
        "token": access_token,
        "user": user.to_dict()
    }), 200