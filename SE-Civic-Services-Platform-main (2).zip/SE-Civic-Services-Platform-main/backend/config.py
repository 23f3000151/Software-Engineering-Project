import os

class Config:
    SECRET_KEY = "civic_services_secret_key"

    SQLALCHEMY_DATABASE_URI = "sqlite:///civic_services.db"

    SQLALCHEMY_TRACK_MODIFICATIONS = False

    JWT_SECRET_KEY = "jwt_secret_key"