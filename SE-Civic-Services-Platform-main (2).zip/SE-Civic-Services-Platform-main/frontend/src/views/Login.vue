<template>
  <div class="container">
    <div class="login-card">
      <h1>Civic Services Platform</h1>
      <p>Citizen Login</p>

      <form @submit.prevent="login">
        <input
          type="email"
          placeholder="Email"
          v-model="email"
          required
        />

        <input
          type="password"
          placeholder="Password"
          v-model="password"
          required
        />

        <button type="submit">Login</button>
      </form>

      <p class="signup-link">
        Don't have an account?
        <router-link to="/signup">Sign Up</router-link>
      </p>
    </div>
  </div>
</template>

<script>
import api from "../api/axios";

export default {
  data() {
    return {
      email: "",
      password: "",
    };
  },

  methods: {
    async login() {
      try {
        const response = await api.post("/auth/login", {
          email: this.email,
          password: this.password,
        });

        localStorage.setItem("token", response.data.token);
        localStorage.setItem("user", JSON.stringify(response.data.user));

        alert("Login Successful!");

        this.$router.push("/dashboard");
      } catch (error) {
        alert(
          error.response?.data?.message || "Invalid email or password."
        );
      }
    },
  },
};
</script>

<style scoped>
.container {
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #eef4fb;
}

.login-card {
  width: 400px;
  background: white;
  padding: 35px;
  border-radius: 12px;
  box-shadow: 0 5px 20px rgba(0,0,0,.15);
}

h1 {
  color: #0b5394;
  text-align: center;
}

p {
  text-align: center;
  margin-bottom: 20px;
}

input {
  width: 100%;
  padding: 12px;
  margin: 12px 0;
  border-radius: 6px;
  border: 1px solid #ccc;
}

button {
  width: 100%;
  padding: 12px;
  background: #0b5394;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}

button:hover {
  background: #073763;
}

.signup-link {
  margin-top: 20px;
}
</style>