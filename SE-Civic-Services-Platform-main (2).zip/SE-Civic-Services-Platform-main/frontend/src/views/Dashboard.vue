<template>
  <div class="dashboard">

    <div class="navbar">
      <h2>Civic Services Platform</h2>

      <button @click="logout">
        Logout
      </button>
    </div>

    <div class="card">

      <h1>Welcome, {{ user.full_name }}</h1>

      <div class="info">
        <p><strong>Email:</strong> {{ user.email }}</p>
        <p><strong>Phone:</strong> {{ user.phone }}</p>
        <p><strong>Role:</strong> {{ user.role }}</p>
      </div>

    </div>

    <div class="services">

      <div class="service-card">
        <h3>Register Complaint</h3>
        <p>Create a new civic complaint.</p>
        <button disabled>Coming Soon</button>
      </div>

      <div class="service-card">
        <h3>Track Complaint</h3>
        <p>Track complaint progress.</p>
        <button disabled>Coming Soon</button>
      </div>

      <div class="service-card">
        <h3>My Complaints</h3>
        <p>View all submitted complaints.</p>
        <button disabled>Coming Soon</button>
      </div>

    </div>

  </div>
</template>

<script>
export default {
  data() {
    return {
      user: {},
    };
  },

  mounted() {
    const token = localStorage.getItem("token");

    if (!token) {
      this.$router.push("/login");
      return;
    }

    this.user = JSON.parse(localStorage.getItem("user"));
  },

  methods: {
    logout() {
      localStorage.removeItem("token");
      localStorage.removeItem("user");

      this.$router.push("/login");
    },
  },
};
</script>

<style scoped>
.dashboard {
  background: #f5f7fb;
  min-height: 100vh;
}

.navbar {
  background: #0b5394;
  color: white;
  padding: 18px 40px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.navbar button {
  background: white;
  color: #0b5394;
  border: none;
  padding: 10px 18px;
  border-radius: 6px;
  cursor: pointer;
}

.card {
  width: 80%;
  margin: 30px auto;
  background: white;
  padding: 25px;
  border-radius: 10px;
  box-shadow: 0 5px 15px rgba(0,0,0,.1);
}

.info p {
  margin: 10px 0;
}

.services {
  width: 80%;
  margin: auto;
  display: flex;
  gap: 20px;
}

.service-card {
  flex: 1;
  background: white;
  padding: 25px;
  border-radius: 10px;
  box-shadow: 0 5px 15px rgba(0,0,0,.1);
  text-align: center;
}

.service-card button {
  margin-top: 15px;
  padding: 10px 18px;
  background: #0b5394;
  color: white;
  border: none;
  border-radius: 6px;
}

.service-card button:disabled {
  background: gray;
  cursor: not-allowed;
}
</style>