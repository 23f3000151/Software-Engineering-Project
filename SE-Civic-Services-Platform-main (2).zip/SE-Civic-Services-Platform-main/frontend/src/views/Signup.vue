<template>
  <div class="container">
    <div class="signup-card">
      <h1>Civic Services Platform</h1>
      <p>Create Your Account</p>

      <form @submit.prevent="signup">

        <input
          type="text"
          placeholder="Full Name"
          v-model="full_name"
          required
        />

        <input
          type="email"
          placeholder="Email"
          v-model="email"
          required
        />

        <input
          type="text"
          placeholder="Phone Number"
          v-model="phone"
          required
        />

        <input
          type="password"
          placeholder="Password"
          v-model="password"
          required
        />

        <button type="submit">
          Create Account
        </button>

      </form>

      <p class="login-link">
        Already have an account?
        <router-link to="/login">
          Login
        </router-link>
      </p>

    </div>
  </div>
</template>

<script>
import api from "../api/axios";

export default {
  data() {
    return {
      full_name: "",
      email: "",
      phone: "",
      password: "",
    };
  },

  methods: {
    async signup() {
      try {
        await api.post("/auth/signup", {
          full_name: this.full_name,
          email: this.email,
          phone: this.phone,
          password: this.password,
        });

        alert("Account created successfully!");

        this.$router.push("/login");
      } catch (error) {
        alert(error.response?.data?.message || "Signup failed");
      }
    },
  },
};
</script>

<style scoped>
.container{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:#eef4fb;
}

.signup-card{
    width:430px;
    background:white;
    padding:35px;
    border-radius:12px;
    box-shadow:0 5px 20px rgba(0,0,0,.15);
}

h1{
    color:#0b5394;
    text-align:center;
}

p{
    text-align:center;
    margin-bottom:20px;
}

input{
    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:6px;
    border:1px solid #ccc;
}

button{
    width:100%;
    padding:12px;
    background:#0b5394;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
    margin-top:10px;
}

button:hover{
    background:#073763;
}

.login-link{
    margin-top:20px;
}
</style>